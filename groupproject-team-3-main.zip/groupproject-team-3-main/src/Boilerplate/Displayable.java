package Boilerplate;
public interface Displayable {
	public void showContents();
	public void hideContents();
}
